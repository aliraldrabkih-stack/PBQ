#!/usr/bin/env python3
import imaplib, email, os, time, json, sys
from email.header import decode_header
from datetime import datetime, timezone, timedelta
from pathlib import Path

IMAP_HOST = os.environ.get("IMAP_HOST", "")
IMAP_PORT = int(os.environ.get("IMAP_PORT", "993"))
IMAP_USER = os.environ.get("IMAP_USER", "")
IMAP_PASS = os.environ.get("IMAP_PASS", "")
UNLOCK_FILE = os.environ.get("UNLOCK_FILE", "/data/unlocked.json")
POLL_INTERVAL = int(os.environ.get("POLL_INTERVAL", "30"))
TARGET_FROM = os.environ.get("TARGET_FROM", "f30s@opg4mers.com").lower()
FLAG = os.environ.get("FLAG", "FLAG{434562465432}")
ACTIVE_WINDOW = int(os.environ.get("ACTIVE_WINDOW", "300"))
IDLE_SLEEP = int(os.environ.get("IDLE_SLEEP", "300"))
TOKENS_FILE = os.environ.get("TOKENS_FILE", "/data/tokens.json")

def load_tokens():
    p = Path(TOKENS_FILE)
    if not p.exists(): return set()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return set(data)
    except:
        pass
    return set()

def decode_subject(msg):
    raw = msg.get("Subject","")
    parts = decode_header(raw)
    subj = ""
    for s, enc in parts:
        if isinstance(s, bytes):
            subj += s.decode(enc or "utf-8", errors="ignore")
        else:
            subj += s
    return subj

def atomic_write_unlock(payload):
    tmp = UNLOCK_FILE + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        os.replace(tmp, UNLOCK_FILE)
        try: os.chmod(UNLOCK_FILE, 0o600)
        except: pass
        return True
    except Exception as e:
        print("Failed to write unlock file:", e, file=sys.stderr)
        return False

def msg_contains_any_token(msg, tokens_set):
    if not tokens_set:
        return False, None
    subj = decode_subject(msg)
    for t in tokens_set:
        if t in subj:
            return True, t
    for part in msg.walk():
        if part.get_content_type() == "text/plain":
            try:
                text = part.get_payload(decode=True).decode(part.get_content_charset() or "utf-8", errors="ignore")
            except:
                text = ""
            for t in tokens_set:
                if t in text:
                    return True, t
    return False, None

def handle_message_and_unlock(msg_id, msg, mail, token):
    try:
        mail.store(msg_id, '+FLAGS', '\\Seen')
    except:
        pass
    payload = {
        "unlocked": True,
        "when": datetime.now(timezone.utc).isoformat(),
        "flag": FLAG,
        "from": email.utils.parseaddr(msg.get("From"))[1],
        "subject": decode_subject(msg),
        "token": token
    }
    if atomic_write_unlock(payload):
        print("[*] Unlocked with token:", token)

def check_once(tokens):
    triggered = False
    try:
        mail = imaplib.IMAP4_SSL(IMAP_HOST, IMAP_PORT)

        # ✅ Zoho-compatible login with fallback
        try:
            mail.login(IMAP_USER, IMAP_PASS)
        except imaplib.IMAP4.error:
            mail.authenticate("PLAIN", lambda _: f"\0{IMAP_USER}\0{IMAP_PASS}".encode("utf-8"))

        mail.select("INBOX")
        typ, data = mail.search(None, 'UNSEEN')
        ids = data[0].split()
        for msg_id in ids:
            typ, msg_data = mail.fetch(msg_id, '(RFC822)')
            if typ != 'OK': continue
            raw = msg_data[0][1]
            msg = email.message_from_bytes(raw)
            from_addr = email.utils.parseaddr(msg.get("From"))[1].lower()
            if TARGET_FROM not in from_addr:
                continue
            found, token = msg_contains_any_token(msg, tokens)
            if found:
                handle_message_and_unlock(msg_id, msg, mail, token)
                triggered = True
        try: mail.logout()
        except: pass
    except Exception as e:
        print("IMAP error:", e, file=sys.stderr)
    return triggered

def main():
    print("[*] Checker started. Poll interval:", POLL_INTERVAL,
          "ACTIVE_WINDOW:", ACTIVE_WINDOW, "IDLE_SLEEP:", IDLE_SLEEP,
          "TARGET_FROM:", TARGET_FROM)
    active_until = None
    while True:
        tokens = load_tokens()
        triggered = check_once(tokens)
        if triggered:
            active_until = datetime.now(timezone.utc) + timedelta(seconds=ACTIVE_WINDOW)
            print("[*] Trigger detected. Active until:", active_until.isoformat())
        now = datetime.now(timezone.utc)
        if active_until is not None and now >= active_until:
            print("[*] Active window expired", now.isoformat())
            time.sleep(IDLE_SLEEP)
            active_until = None
            continue
        time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    main()
