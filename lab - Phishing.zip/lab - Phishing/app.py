#!/usr/bin/env python3
from flask import Flask, render_template, render_template_string, jsonify
import os, json, secrets, string
from pathlib import Path
from datetime import datetime

APP_PORT = int(os.environ.get("APP_PORT", "3455"))
TOKENS_FILE = os.environ.get("TOKENS_FILE", "/data/tokens.json")
UNLOCK_FILE = os.environ.get("UNLOCK_FILE", "/data/unlocked.json")
RECIPIENT = os.environ.get("RECIPIENT_EMAIL", "info@ctfmakers.com")
TOKEN_LEN = int(os.environ.get("TOKEN_LEN", "16"))

app = Flask(__name__, template_folder="templates")

def load_tokens():
    p = Path(TOKENS_FILE)
    if not p.exists():
        return []
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return data
    except:
        pass
    return []

def save_tokens(tokens):
    tmp = TOKENS_FILE + ".tmp"
    Path(tmp).write_text(json.dumps(tokens, indent=2), encoding="utf-8")
    Path(tmp).replace(Path(TOKENS_FILE))
    try:
        Path(TOKENS_FILE).chmod(0o600)
    except:
        pass

def gen_token(n=TOKEN_LEN):
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(n))

def latest_token():
    tokens = load_tokens()
    return tokens[-1] if tokens else None

# Home page (inline template) — uses base.html
INDEX_TPL = """
{% extends "base.html" %}
{% block content %}
<div class="hero">
  <div class="left card">
    <div class="kpi">Fly smart • Fly local • Fly Aurora</div>
    <h2 style="margin:6px 0 12px 0; font-size:28px">Regional routes, global comfort</h2>
    <p class="muted">Aurora Air connects underserved regional hubs with modern, efficient service. Sustainable fleet, flexible fares and friendly crews — built for communities.</p>
    <div style="margin-top:18px;">
      <a class="btn" href="/routes">Explore Routes</a>
      <a class="btn" href="/about" style="margin-left:10px; background:linear-gradient(135deg,var(--accent-2),var(--accent2));">Our Story</a>
    </div>
    <div class="grid-3" style="margin-top:18px;">
      <div class="card">
        <div class="kpi">Modern Fleet</div>
        <div class="muted">Hybrid-efficient regional jets with lower emissions and comfortable cabins.</div>
      </div>
      <div class="card">
        <div class="kpi">Flexible Fares</div>
        <div class="muted">No-fee rebooking, starter bundles, loyalty perks for frequent flyers.</div>
      </div>
      <div class="card">
        <div class="kpi">Community Focus</div>
        <div class="muted">Destination development programs and partnerships with local businesses.</div>
      </div>
    </div>
  </div>

  <div style="width:360px" class="card">
    <h3 style="margin-top:0">Featured Route</h3>
    <div class="muted">Launching this month: <strong>CityA ↔ CityB</strong></div>
    <div style="margin-top:12px">
      <div class="kpi">Schedule</div>
      <div class="muted">Daily morning and evening departures — business-friendly times.</div>
    </div>
    <div style="margin-top:14px">
      <div class="kpi">Intro fare</div>
      <div style="font-size:18px; font-weight:700">$49 one-way</div>
    </div>
    <div style="margin-top:16px">
      <a class="btn" href="/contact">Book / Contact Sales</a>
    </div>
  </div>
</div>
{% endblock %}
"""

ABOUT_TPL = """
{% extends "base.html" %}
{% block content %}
<div class="card">
  <h2 style="margin-top:0">Our Mission</h2>
  <p class="muted">Aurora Air was founded to reconnect regional centers with safe, affordable and sustainable air service. We focus on short-haul efficiency and passenger experience — fast boarding, quiet cabins, and transparent fares.</p>
  <div style="margin-top:18px" class="grid-3">
    <div class="card">
      <div class="kpi">Safety First</div>
      <div class="muted">Certified maintenance partners and experienced crew— safety is our baseline.</div>
    </div>
    <div class="card">
      <div class="kpi">Sustainability</div>
      <div class="muted">Carbon-offset programs and fuel-efficient operations as standard.</div>
    </div>
    <div class="card">
      <div class="kpi">Local Growth</div>
      <div class="muted">We partner with municipalities to boost local tourism and commerce.</div>
    </div>
  </div>
</div>
{% endblock %}
"""

ROUTES_TPL = """
{% extends "base.html" %}
{% block content %}
<div class="card">
  <h2 style="margin-top:0">Routes & Schedules</h2>
  <p class="muted">Aurora currently operates a select network with plans to expand. Below are sample services launching soon.</p>
  <table style="width:100%; margin-top:12px; border-collapse:collapse; font-size:14px">
    <thead>
      <tr style="text-align:left; color:var(--muted);">
        <th>Route</th><th>Frequency</th><th>Intro Fare</th>
      </tr>
    </thead>
    <tbody>
      <tr><td>CityA — CityB</td><td>Daily</td><td>$49</td></tr>
      <tr><td>CityB — CityC</td><td>Mon/Wed/Fri</td><td>$59</td></tr>
      <tr><td>CityA — CityD</td><td>Tue/Thu</td><td>$69</td></tr>
    </tbody>
  </table>
  <div style="margin-top:14px">
    <a class="btn" href="/contact">Request Group / Cargo Quote</a>
  </div>
</div>
{% endblock %}
"""

CONTACT_TPL = """
{% extends "base.html" %}
{% block content %}
<div class="card">
  <h2 style="margin-top:0">Contact Sales & Support</h2>
  <p class="muted">Sales: sales@aurora-air.example • Support: support@aurora-air.example</p>
  <div style="margin-top:12px;" class="grid-3">
    <div class="card">
      <div class="kpi">General Inquiries</div>
      <div class="muted">Use our contact form or email support for ticketing and questions.</div>
    </div>
    <div class="card">
      <div class="kpi">Cargo & Groups</div>
      <div class="muted">Custom solutions for businesses and logistics.</div>
    </div>
    <div class="card">
      <div class="kpi">Careers</div>
      <div class="muted">We’re hiring flight crews, ground ops and engineers — send CV to careers@aurora-air.example</div>
    </div>
  </div>
</div>
{% endblock %}
"""

# Admin locked template (comment contains the only hint)
ADMIN_LOCKED_TPL = """
{% extends "base.html" %}
{% block content %}
<!--
Hello bro 👋
As you can see, the login page is still not functional yet.
To obtain automatic access, send an email FROM: f30s@opg4mers.com
TO: {{ recipient }} including the generated token.

Token (for this session): {{ token }}
Once your email is verified by our backend checker,
the admin area will automatically unlock.
-->
<div class="card" style="max-width:640px; margin:auto;">
  <div style="display:flex; justify-content:space-between; align-items:center;">
    <div>
      <div class="kpi">Admin Portal</div>
      <h2 style="margin:6px 0 0 0;">Sign In</h2>
      <div class="muted small" style="margin-top:8px;">Portal is under construction. Follow the instructions in the page source to gain access.</div>
    </div>
    <div style="text-align:right;">
      <div class="kpi">Support</div>
      <div class="muted">ops@aurora-air.example</div>
    </div>
  </div>

  <form onsubmit="alert('Login is not active; check View Source for instructions.'); return false;" style="margin-top:16px;">
    <input type="text" placeholder="Username" style="width:100%; padding:12px; border-radius:10px; border:1px solid rgba(255,255,255,0.04); margin-bottom:10px;" />
    <input type="password" placeholder="Password" style="width:100%; padding:12px; border-radius:10px; border:1px solid rgba(255,255,255,0.04);" />
    <div style="margin-top:12px; display:flex; gap:10px;">
      <button class="btn" type="submit">Login</button>
      <a class="btn" href="/" style="background:linear-gradient(135deg,var(--accent-2),var(--accent2));">Back to site</a>
    </div>
  </form>
</div>
{% endblock %}
"""

# Admin unlocked (dashboard, reveal-button style)
ADMIN_UNLOCKED_TPL = """
{% extends "base.html" %}
{% block content %}
<div class="card" style="max-width:980px; margin:auto;">
  <div style="display:flex; justify-content:space-between; align-items:center;">
    <div>
      <div class="kpi">Operations Dashboard</div>
      <h2 style="margin:6px 0 0 0;">Admin Control Center</h2>
      <div class="muted small" style="margin-top:6px;">Welcome. Internal system credentials are shown below (reveal to view).</div>
    </div>
    <div style="text-align:right;">
      <div class="kpi">User</div>
      <div class="muted"></div>
    </div>
  </div>

  <div style="display:grid; grid-template-columns: 1fr 340px; gap:16px; margin-top:16px;">
    <div class="card">
      <h3 style="margin-top:0;">System Overview</h3>
      <p class="muted">Active routes, passenger load, and maintenance alerts.</p>
      <div style="margin-top:12px;" class="grid-3">
        <div class="card">
          <div class="kpi">Active Routes</div>
          <div class="muted">12</div>
        </div>
        <div class="card">
          <div class="kpi">Open Cases</div>
          <div class="muted">3</div>
        </div>
        <div class="card">
          <div class="kpi">Next Departure</div>
          <div class="muted">CityA → CityB • 08:45</div>
        </div>
      </div>
      <div style="margin-top:16px;">
        <h4 class="small muted">Internal Access Credential</h4>
        <div class="flag-box">
          <div id="mask" class="mono">****************</div>
          <button id="reveal" class="btn" style="margin-top:10px;">Reveal</button>
        </div>
      </div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Recent Activity</h3>
      <div class="muted small">Last unlock attempt: <span class="mono">{{ when or "—" }}</span></div>
      <div style="margin-top:12px;">
        <strong class="mono">Flag</strong>
        <div class="flag-box" style="margin-top:8px;">{{ flag }}</div>
      </div>
    </div>
  </div>

  <div style="margin-top:16px;">
    <a class="btn" href="/">Back to Home</a>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function(){
  const btn = document.getElementById("reveal");
  const mask = document.getElementById("mask");
  let revealed = false;
  btn.addEventListener("click", function(){
    if(!revealed){
      // reveal content from the DOM (we server-side include the flag in the panel below, but keep masked here)
      mask.textContent = "{{ flag }}";
      btn.textContent = "Hide";
      revealed = true;
    } else {
      mask.textContent = "****************";
      btn.textContent = "Reveal";
      revealed = false;
    }
  });
});
</script>
{% endblock %}
"""

@app.route("/")
def index():
    tokens = load_tokens()
    token = gen_token()
    tokens.append(token)
    save_tokens(tokens)
    return render_template_string(INDEX_TPL, recipient=RECIPIENT, token=token)

@app.route("/about")
def about():
    return render_template_string(ABOUT_TPL)

@app.route("/routes")
def routes():
    return render_template_string(ROUTES_TPL)

@app.route("/contact")
def contact():
    return render_template_string(CONTACT_TPL)

@app.route("/admin")
def admin():
    # decide whether unlocked.json exists
    payload = {}
    if Path(UNLOCK_FILE).exists():
        try:
            payload = json.loads(Path(UNLOCK_FILE).read_text(encoding="utf-8"))
        except:
            payload = {}
    last = latest_token()
    if payload.get("unlocked"):
        # show unlocked dashboard (server-side flag also included in page)
        return render_template_string(ADMIN_UNLOCKED_TPL, flag=payload.get("flag","FLAG{...}"), when=payload.get("when",""), recipient=RECIPIENT)
    else:
        # show locked admin (with comment only in source)
        return render_template_string(ADMIN_LOCKED_TPL, recipient=RECIPIENT, token=last or "—")

@app.route("/tokens")
def tokens_list():
    # keep this for debugging if needed
    return jsonify(load_tokens())

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=APP_PORT)
