# CTF Web + Checker demo

1) Copy .env.example to .env and edit IMAP info:
   cp .env.example .env
   # then edit IMAP_HOST, IMAP_USER, IMAP_PASS

2) Ensure data folder and permissions:
   mkdir -p data
   sudo chown -R 1000:1000 data
   sudo chmod -R 770 data

3) Run:
   docker compose up --build -d

4) Open:
   http://localhost:3455

5) Exercise flow:
   - Open / to get a token (generated per-visit)
   - Open /admin -> View Source to find the comment with the token
   - Send an email from the approved sender (TARGET_FROM in .env) to info@ctfmakers.com including the token
   - Watch checker logs: docker logs -f ctf_checker
   - When detected, open /admin to see FLAG
